#!/bin/bash

java -jar /data/account/*.jar > /dev/null 2> /dev/null < /dev/null &
