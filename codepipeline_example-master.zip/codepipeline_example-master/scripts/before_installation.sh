#!/bin/bash

sudo apt install openjdk-8-jdk -y && sudo apt install maven -y

touch /var/log/java.service
