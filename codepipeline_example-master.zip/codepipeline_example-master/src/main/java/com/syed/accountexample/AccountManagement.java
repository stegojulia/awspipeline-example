package com.syed.accountexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountManagement {

	public static void main(String[] args) {
		SpringApplication.run(AccountManagement.class, args);
	}

}
